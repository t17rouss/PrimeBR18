package net;
import java.io.* ;
import gnu.io.*;
import java.util.*;


public class LectureTrajectoire {
	public static String nomFichier = "/home/thomas/Documents/vitesses.txt";
	public static double COEFFICIENT_MOTEUR =61.26/50 ;
	//Ke=61.26 RAD/S/V
	public static double COEFFICIENT_ANGLE = 2*Math.PI ;
	public static double data[] = new double [4] ;
	public static int LEN_MAX = 100 ;
	
	public static Vector extraireFichier () {
		Vector<int[]> dataset = new Vector();
		try {
			BufferedReader aLire = new BufferedReader(new FileReader(nomFichier));
			String line1 = new String(aLire.readLine()); 
			for (int i =0 ; i<4 ; i++) {
				Double.parseDouble(line1.split(";",0)[i]);
			}
			int cpt = 0 ; 
			do {
				String currentLine = aLire.readLine() ;
				if(currentLine != null) {
					int currentTab[] = new int [4];
					for (int i =0 ; i<2; i++) {
						System.out.println(currentLine);
						currentTab[2*i] = (int) (((Double.parseDouble(currentLine.split(";",0)[2*i])/COEFFICIENT_MOTEUR)+18)/36*254);
						double a = (Double.parseDouble(currentLine.split(";",0)[2*i+1]))%(2*Math.PI);
						//System.out.println(a);
						if (a<0) {
			
							a=2*Math.PI+a;
						}
						currentTab[2*i+1] = (int)(a*254/COEFFICIENT_ANGLE);
						
					}
					System.out.println(currentTab[2]);
					dataset.addElement(currentTab);
					cpt++ ;
				}

			}while (aLire!=null && cpt <LEN_MAX) ;
			
			aLire.close();
		}
		catch (IOException e) {
			System.out.println("Exception raised");
		}
		
		return dataset ;
		
	}
	
	public static void envoiData(int [] dataset) {
		
	}
	
	
	public static void main(String[] args) {
		
		System.out.println(extraireFichier());
		
	}
}
