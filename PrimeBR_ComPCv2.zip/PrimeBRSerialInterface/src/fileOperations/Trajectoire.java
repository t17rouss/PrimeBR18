package fileOperations;

import java.io.IOException;

public class Trajectoire {
	
	private int size ;
	private Double [] metaData ;
	private int  [][] values ;
	
	
	public Trajectoire ( String nomFichier) {
		try {
			this.size = LectureTrajectoire.countLines(nomFichier) ;
			this.metaData = LectureTrajectoire.getMetaData(nomFichier);
			this.values  = LectureTrajectoire.extraireFichier(nomFichier, size);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public Double [] getMetaData () {
		return this.metaData ;
	}
	
	public int getSize() {
		return this.size ;
	}
	
	public int [][] getSegment (int startIndex, int maxLength) {
		int a = maxLength ;
		int [][] segment ;
		if (this.getSize()>=startIndex+maxLength) {
			segment = new int [a][4];
		} else {
			a = this.getSize()-startIndex ;
			segment = new int [a][4] ;	
		} 
		for (int i = 0 ; i<a ; i++) {
			segment [i] = this.values[startIndex + i] ;
		}
		return segment ;
	}

}
