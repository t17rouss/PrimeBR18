package fileOperations;
import java.io.* ;


public class LectureTrajectoire {
	
	public static double COEFFICIENT_MOTEUR =61.26/50 ;
	//Ke=61.26 RAD/S/V
	public static double COEFFICIENT_ANGLE = 2*Math.PI ;
	
	/*FONCTIONS UTILES POUR LA LECTURE DES FICHIERS DE VITESSE
	 * Lecture du fichier de vitesses fourni format� ainsi :
	 * Ligne 1 : Valeurs caract�ristiques de la mod�lisation
	 * Ligne 2..* Tableaux w1 w2 a1 a2
	 */

	// Retourne la longueur du fichier (plus rapide que readLines)
	//Source : https://stackoverflow.com/questions/453018/number-of-lines-in-a-file-in-java
	
	public static int countLines(String nomFichier) throws IOException {
	    InputStream is = new BufferedInputStream(new FileInputStream(nomFichier));
	    try {
	        byte[] c = new byte[1024];
	        int count = 0;
	        int readChars = 0;
	        boolean empty = true;
	        while ((readChars = is.read(c)) != -1) {
	            empty = false;
	            for (int i = 0; i < readChars; ++i) {
	                if (c[i] == '\n') {
	                    ++count;
	                }
	            }
	        }
	        return (count == 0 && !empty) ? 1 : count;
	    } finally {
	        is.close();
	    }
	}
	
	/*
	 * extraireFichier( "nomFichier.txt", 100) retourne un tableau 2D d'entiers de taille longueur
	 * du fichier * 4
	 * La ligne 0 est ignor�e (informations g�n�riques)
	 */
	
	public static Double [] getMetaData (String nomFichier) {
		Double [] metaData = new Double [4] ;
		try {
			BufferedReader aLire = new BufferedReader(new FileReader(nomFichier));
			String line1 = new String(aLire.readLine()); 
			for (int i =0 ; i<4 ; i++) {
				metaData[i] = Double.parseDouble(line1.split(";",0)[i]);
			}
			aLire.close();
		}catch (IOException e) {
				System.out.println("Erreur e");
			}
		
		return metaData ;
	}
	
	public static int [][] extraireFichier (String nomFichier , int taille) {
		int [][] dataset = new int [taille - 1][4];
		try {
			BufferedReader aLire = new BufferedReader(new FileReader(nomFichier));
			aLire.readLine(); //On passe la ligne 0
			int cpt = 0 ; 
			do {
				String currentLine = aLire.readLine() ;
				if(currentLine != null) {
					int currentTab[] = new int [4];
					for (int i =0 ; i<2; i++) {
						System.out.println(currentLine);
						currentTab[2*i] = (int) (((Double.parseDouble(currentLine.split(";",0)[2*i])/COEFFICIENT_MOTEUR)+18)/36*254);
						double a = (Double.parseDouble(currentLine.split(";",0)[2*i+1]))%(2*Math.PI);
						//System.out.println(a);
						if (a<0) {
			
							a=2*Math.PI+a;
						}
						currentTab[2*i+1] = (int)(a*254/COEFFICIENT_ANGLE);
						
					}
					System.out.println(currentTab[2]);
					dataset[cpt] = currentTab ;
					cpt++ ;
				}

			}while (aLire!=null) ;
			
			aLire.close();
		}
		catch (IOException e) {
			System.out.println("Exception raised");
		}
		
		return dataset ;
		
	}

}
