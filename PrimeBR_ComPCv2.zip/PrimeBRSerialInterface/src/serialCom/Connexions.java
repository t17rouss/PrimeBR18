package serialCom;
import net.Network;
import java.io.* ;
import java.util.Vector;

public class Connexions implements net.Network_iface {
	
	//vitesse du port
	public static int speed = 19200 ;
	private static Network network ;
	
	private static boolean resend_active = false;
	

	@Override
	public void writeLog(int id, String text) {
		System.out.println("   log:  |" + text + "|");
		
	}

	@Override
	public void parseInput(int id, int numBytes, int[] message) {
		if (resend_active) {
			network.writeSerial(numBytes, message);
			System.out.print("received and sent back the following message: ");
		} else {
			System.out.print("received the following message: ");
		}
		System.out.print(message[0]);
		for (int i = 1; i < numBytes; ++i) {
			System.out.print(", ");
			System.out.print(message[i]);
		}
		System.out.println();
		
	}

	@Override
	public void networkDisconnected(int id) {
		System.exit(0);
		
	}
	
	public static void main(String[] args) {
		//INITIALISATIONS :
		// cr�ation de l'objet network
		network = new Network(0, new Connexions (), 255) ;
		
		int i = 0 ;
		int inputNumber = 0;
		String input ;
		//initialisation lecteur
		BufferedReader in_stream = new BufferedReader (new InputStreamReader(System.in)) ;
		
		// getting a list of the available serial ports
		Vector<String> ports = network.getPortList();

		// choosing the port to connect to
		System.out.println();
		if (ports.size() > 0) {
			System.out
					.println("the following serial ports have been detected:");
		} else {
			System.out
					.println("sorry, no serial ports were found on your computer\n");
			System.exit(0);
		}
		for (i = 0; i < ports.size(); ++i) {
			System.out.println("    " + Integer.toString(i + 1) + ":  "
					+ ports.elementAt(i));
		}
		boolean valid_answer = false;
		while (!valid_answer) {
			System.out
					.println("enter the id (1,2,...) of the connection to connect to: ");
			try {
				input = in_stream.readLine();
				inputNumber = Integer.parseInt(input);
				if ((inputNumber < 1) || (inputNumber >= ports.size() + 1))
					System.out.println("your input is not valid");
				else
					valid_answer = true;
			} catch (NumberFormatException ex) {
				System.out.println("please enter a correct number");
			} catch (IOException e) {
				System.out.println("there was an input error\n");
				System.exit(1);
			}
		}

		// connecting to the selected port
		if (network.connect(ports.elementAt(inputNumber - 1), speed)) {
			System.out.println();
		} else {
			System.out.println("sorry, there was an error connecting\n");
			System.exit(1);
		}

		// asking whether user wants to mirror traffic
		System.out
				.println("do you want this tool to send back all the received messages?");
		valid_answer = false;
		while (!valid_answer) {
			System.out.println("'y' for yes or 'n' for no: ");
			try {
				input = in_stream.readLine();
				if (input.equals("y")) {
					resend_active = true;
					valid_answer = true;
				} else if (input.equals("n")) {
					valid_answer = true;
				} else if (input.equals("q")) {
					System.out.println("example terminated\n");
					System.exit(0);
				}
			} catch (IOException e) {
				System.out.println("there was an input error\n");
				System.exit(1);
			}
		}

		// reading in numbers (bytes) to be sent over the serial port
		System.out.println("type 'q' to end the example");
		while (true) {
			try {
				Thread.sleep(1000);
			} catch (InterruptedException e1) {
			}
			System.out
					.println("\nenter a number between 0 and 254 to be sent ('q' to exit): ");
			try {
				input = in_stream.readLine();
				if (input.equals("q")) {
					System.out.println("example terminated\n");
					network.disconnect();
					System.exit(0);
				}
				inputNumber = Integer.parseInt(input);
				if ((inputNumber > 255) || (inputNumber < 0)) {
					System.out.println("the number you entered is not valid");
				} else {
					int temp[] = { inputNumber };
					network.writeSerial(1, temp);
					System.out.println("sent " + inputNumber + " over the serial port");
				}
			} catch (NumberFormatException ex) {
				System.out.println("please enter a correct number");
			} catch (IOException e) {
				System.out.println("there was an input error");
			}
		}
		
	}

}
