package serialCom;

import gnu.io.*;
import java.io.*;
import java.util.Enumeration;

public class Connexions {

	// vitesse du port
	public static int speed = 9600;

	public static void main(String[] args) {
		// INITIALISATIONS :

		String wantedPortName = "/dev/tty0";
		//
		// Get an enumeration of all ports known to JavaComm
		//
		Enumeration<?> portIdentifiers = CommPortIdentifier.getPortIdentifiers();
		//
		// Check each port identifier if
		// (a) it indicates a serial (not a parallel) port, and
		// (b) matches the desired name.
		//
		CommPortIdentifier portId = null; // will be set if port found
		while (portIdentifiers.hasMoreElements()) {
			CommPortIdentifier pid = (CommPortIdentifier) portIdentifiers.nextElement();
			if (pid.getPortType() == CommPortIdentifier.PORT_SERIAL && pid.getName().equals(wantedPortName)) {
				portId = pid;
				break;
			}
		}
		System.out.println(portId);
		
		SerialPort port = null;
		
		try {
			port = (SerialPort) portId.open( "Connexions", // Name of the application asking for the port
					10000 // Wait max. 10 sec. to acquire port
			);
		} catch (PortInUseException e) {
			System.err.println("Port already in use: " + e);
			System.exit(1);
		}

		try {
			port.setSerialPortParams(9600, SerialPort.DATABITS_8, SerialPort.STOPBITS_1, SerialPort.PARITY_NONE);
		} catch (UnsupportedCommOperationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}

		//
		// Open the input Reader and output stream. The choice of a
		// Reader and Stream are arbitrary and need to be adapted to
		// the actual application. Typically one would use Streams in
		// both directions, since they allow for binary data transfer,
		// not only character data transfer.
		//

		BufferedReader input_s = null; // for demo purposes only. A stream would be more typical.
		PrintStream output_s = null;

		try {
			input_s = new BufferedReader(new InputStreamReader(port.getInputStream()));
		} catch (IOException e) {
			System.err.println("Can't open input stream: write-only");
			input_s = null;
		}

		//
		// New Linux systems rely on Unicode, so it might be necessary to
		// specify the encoding scheme to be used. Typically this should
		// be US-ASCII (7 bit communication), or ISO Latin 1 (8 bit
		// communication), as there is likely no modem out there accepting
		// Unicode for its commands. An example to specify the encoding
		// would look like:
		//
		// output_s = new PrintStream(port.getOutputStream(), true, "ISO-8859-1");
		//
		try {
			output_s = new PrintStream(port.getOutputStream(), true);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		//
		// Actual data communication would happen here
		// performReadWriteCode();
		//

		//
		// It is very important to close input and output streams as well
		// as the port. Otherwise Java, driver and OS resources are not released.
		//
		if (input_s != null)
			try {
				input_s.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		if (output_s != null)
			output_s.close();
		if (port != null)
			port.close();

	}

}
